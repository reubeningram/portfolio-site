# Feed Reader Project
Author: Reuben Ingram
Date: 1/31/2018

## Table of Contents

# Project Overview
# Starting the application


# Project Overview
This project is a web-based application that reads RSS feeds. Using JasmineJS, various aspects of the program will be tested to ensure proper functionality.  

# [Starting the application] [#Starting the application]
The application can be started by opening the file, "index.html", located within the root of the zipped file provided. Located at the bottom, are the results 
from Jasmine.Js, where a total of 8 specs are written, within a total of 4 suites.

Each spec will validate a portion of the application, ensuring that feeds are properly being populated and verified.
